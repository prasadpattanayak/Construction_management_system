package com.example.user.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.User;
import com.example.user.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	UserService service;
	
	@GetMapping("/getAllUser")
	public List<User> getAllUser(){
		return service.getAllUser();
	}
	
	@GetMapping("/getUserById/{id}")
	public ResponseEntity<String> getUserById(@PathVariable (value = "id") int id){
		try {
		User user = service.getUserById(id);
		if (user.equals(null)) {
			return new ResponseEntity(HttpStatus.NOT_FOUND).ok("User doesn't exists: "  +id);
		} else {
			return new ResponseEntity(HttpStatus.FOUND).ok(user.toString());
		}
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/getUserById/{email}")
	public ResponseEntity<String> getUserByEmail(@PathVariable (value = "email") String email){
		
		try {
			User user = service.getUserByEmail(email);
			if (user.equals(null)) {
				return new ResponseEntity(HttpStatus.NOT_FOUND).ok("User doesn't exists: "  +email);
			} else {
				return new ResponseEntity(HttpStatus.FOUND).ok(user.toString());
			}
			}catch(Error error) {
				return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
			}
		
	}
	
	@GetMapping("/getUserById/{phone}")
	public ResponseEntity<String> getUserByPhone(@PathVariable (value = "email") String phone){
		try {
			User user = service.getUserByPhone(phone);
			if (user.equals(null)) {
				return new ResponseEntity(HttpStatus.NOT_FOUND).ok("User doesn't exists: "  +phone);
			} else {
				return new ResponseEntity(HttpStatus.FOUND).ok(user.toString());
			}
			}catch(Error error) {
				return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
			}
	}
	
	@PostMapping("/saveUser")
	public  ResponseEntity<String> saveUser(@RequestBody User user) {
		try {
			return new ResponseEntity(HttpStatus.CREATED).ok("User created successfully: "  + user.toString());
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/updateUser/{id}")
	public ResponseEntity<String> updateUser(@RequestBody User user) {

		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("User created successfully: "  + service.updateUser(user));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
		
		
	}
	
	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable (value = "id") int id) {
		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("User created successfully: "  + service.deleteUser(id));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
}
