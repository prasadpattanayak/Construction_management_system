package com.example.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.model.User;
import com.example.user.repo.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository repo;
	
	public List<User> getAllUser(){
		return repo.findAll();
	}
	
	public User getUserById(int id){
		Optional<User> optional = repo.findById(id);
		User user = null;
		if (optional.isPresent()) {
			user = optional.get();
		} else {
			throw new RuntimeException(" User not found for id : " + id);
		}
		return user;
	}
	
	public User getUserByEmail(String email){
		Optional<User> optional = repo.findAll().stream().filter((e) -> e.getEmail().equals(email)).findFirst();
		User user = null;
		if(optional.isPresent()) {
			user = optional.get();
		}else {
			throw new RuntimeException("User not found for id: " + email);
		}
		return user;
	}
	
	public User getUserByPhone(String phone){
		Optional<User> optional = repo.findAll().stream().filter((e) -> e.getPhone().equals(phone)).findFirst();
		User user = null;
		if(optional.isPresent()) {
			user = optional.get();
		}else {
			throw new RuntimeException("User not found for id: " + phone);
		}
		return user;
	}
	
	public String saveUser(User user) {
		try {
		return repo.save(user).toString() + "/n User Created Successfully";
		}catch(Error error) {
			return "Some error occurred!!!";
		}
	}
	
	public String updateUser(User user) {
		User oldUser = getUserByEmail(user.getEmail());
		
		try{
			oldUser.setId(user.getId());
			oldUser.setName(user.getName());
			oldUser.setEmail(user.getEmail());
			oldUser.setPhone(user.getPhone());
			oldUser.setPassword(user.getPassword());
			return repo.save(oldUser).toString() + "/n User Updated Successfully";
		}catch(Error error) {
			return "User doesn't exists";
		}
		
		
	}
	
	public String deleteUser(int id) {
		try{
			repo.deleteById(id);
			return "User deleted successfully";
		}catch(Error error) {
			return "User doesn't exists";
		}
	}
}
