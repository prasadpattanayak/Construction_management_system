package com.example.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.Role;
import com.example.user.service.RoleService;
import com.example.user.service.RoleService;

@RestController
@RequestMapping("/roles")
public class RoleController {

	@Autowired
	RoleService service;
	
	@GetMapping("/getAllRole")
	public List<Role> getAllRole(){
		return service.getAllRoles();
	}
	
	@GetMapping("/getRoleById/{id}")
	public ResponseEntity<String> getRoleById(@PathVariable (value = "id") int id){
		try {
		Role role = service.getRoleById(id);
		if (role.equals(null)) {
			return new ResponseEntity(HttpStatus.NOT_FOUND).ok("Role doesn't exists: "  +id);
		} else {
			return new ResponseEntity(HttpStatus.FOUND).ok(role.toString());
		}
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/saveRole")
	public  ResponseEntity<String> saveRole(@RequestBody Role role) {
		try {
			return new ResponseEntity(HttpStatus.CREATED).ok("Role created successfully: "  + role.toString());
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/updateRole/{id}")
	public ResponseEntity<String> updateRole(@RequestBody Role role) {

		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("Role created successfully: "  + service.updateRole(role));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
		
		
	}
	
	@DeleteMapping("/deleteRole/{id}")
	public ResponseEntity<String> deleteRole(@PathVariable (value = "id") int id) {
		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("Role created successfully: "  + service.deleteRole(id));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
}
