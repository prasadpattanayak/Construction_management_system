package com.example.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.Project;
import com.example.user.service.ProjectService;

@RestController
@RequestMapping("/project")
public class ProjectController {

	@Autowired
	ProjectService service;
	
	@GetMapping("/getAllProject")
	public List<Project> getAllProject(){
		return service.getAllProjects();
	}
	
	@GetMapping("/getProjectById/{id}")
	public ResponseEntity<String> getProjectById(@PathVariable (value = "id") int id){
		try {
		Project project = service.getProjectById(id);
		if (project.equals(null)) {
			return new ResponseEntity(HttpStatus.NOT_FOUND).ok("Project doesn't exists: "  +id);
		} else {
			return new ResponseEntity(HttpStatus.FOUND).ok(project.toString());
		}
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/saveProject")
	public  ResponseEntity<String> saveProject(@RequestBody Project project) {
		try {
			return new ResponseEntity(HttpStatus.CREATED).ok("Project created successfully: "  + project.toString());
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/updateProject/{id}")
	public ResponseEntity<String> updateProject(@RequestBody Project project) {

		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("Project created successfully: "  + service.updateProject(project));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
		
		
	}
	
	@DeleteMapping("/deleteProject/{id}")
	public ResponseEntity<String> deleteProject(@PathVariable (value = "id") int id) {
		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("Project created successfully: "  + service.deleteProject(id));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
}
