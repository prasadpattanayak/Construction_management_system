package com.example.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.model.Project;
import com.example.user.model.Role;
import com.example.user.repo.RoleRepository;

@Service
public class RoleService {

	@Autowired
	RoleRepository repo;
	
	public List<Role> getAllRoles(){
		return repo.findAll();
	}
	
	public Role getRoleById(int id){
		Optional<Role> optional = repo.findById(id);
		Role role = null;
		if (optional.isPresent()) {
			role = optional.get();
		} else {
			throw new RuntimeException(" Role doesn't exists with the following id: " + id);
		}
		return role;
	}
	
	public String saveRole(Role role) {
		try {
		return repo.save(role).toString() + "/n Role Created Successfully";
		}catch(Error error) {
			return "Some error occurred while creating Role!!!";
		}
	}
	
	public String updateRole(Role role) {
		Role oldRole = getRoleById(role.getrId());
		
		try{
			oldRole.setrId(role.getrId());
			oldRole.setrName(role.getrName());
			
			return repo.save(oldRole).toString() + "/n Role Updated Successfully";
		}catch(Error error) {
			return "User doesn't exists";
		}
		
		
	}
	
	public String deleteRole(int id) {
		try{
			repo.deleteById(id);
			return "Role deleted successfully";
		}catch(Error error) {
			return "Role doesn't exists";
		}
	}
}
