package com.example.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.model.Project;
import com.example.user.model.Property;
import com.example.user.repo.PropertyRepository;

@Service
public class PropertyService {
	
	@Autowired
	PropertyRepository repo;
	
	public List<Property> getAllProperties(){
		return repo.findAll();
	}
	
	public Property getPropertyById(int id){
		Optional<Property> optional = repo.findById(id);
		Property property = null;
		if (optional.isPresent()) {
			property = optional.get();
		} else {
			throw new RuntimeException(" User not found for id : " + id);
		}
		return property;
	}
	
	public String saveProperty(Property property) {
		try {
		return repo.save(property).toString() + "/n Property Created Successfully";
		}catch(Error error) {
			return "Some error occurred while adding a property!!!";
		}
	}
	
	public String updateProperty(Property property) {
		Property oldProperty = getPropertyById(property.getPropertyId());
		
		try{
			oldProperty.setPropertyId(property.getPropertyId());
			oldProperty.setPropertyName(property.getPropertyName());
			oldProperty.setPropertyLocation(property.getPropertyLocation());
			
			return repo.save(oldProperty).toString() + "/n User Updated Successfully";
		}catch(Error error) {
			return "User doesn't exists";
		}
		
		
	}
	
	public String deleteProperty(int id) {
		try{
			repo.deleteById(id);
			return "Property deleted successfully";
		}catch(Error error) {
			return "Property doesn't exists";
		}
	}

}
