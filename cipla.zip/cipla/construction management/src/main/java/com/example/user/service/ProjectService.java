package com.example.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.model.Project;
import com.example.user.repo.ProjectRepository;

@Service
public class ProjectService {
	@Autowired
	ProjectRepository repo;
	
	public List<Project> getAllProjects(){
		return repo.findAll();
	}
	
	public Project getProjectById(int id){
		Optional<Project> optional = repo.findById(id);
		Project project = null;
		if (optional.isPresent()) {
			project = optional.get();
		} else {
			throw new RuntimeException(" User not found for id : " + id);
		}
		return project;
	}
	
	public String saveProject(Project project) {
		try {
		return repo.save(project).toString() + "/n Project Created Successfully";
		}catch(Error error) {
			return "Some error occurred!!!";
		}
	}
	
	public String updateProject(Project project) {
		Project oldProject = getProjectById(project.getPid());
		
		try{
			oldProject.setPid(project.getPid());
			oldProject.setpName(project.getpName());
			oldProject.setpManager(project.getpManager());
			
			return repo.save(oldProject).toString() + "/n User Updated Successfully";
		}catch(Error error) {
			return "User doesn't exists";
		}
		
		
	}
	
	public String deleteProject(int id) {
		try{
			repo.deleteById(id);
			return "Project deleted successfully";
		}catch(Error error) {
			return "Project doesn't exists";
		}
	}
}
