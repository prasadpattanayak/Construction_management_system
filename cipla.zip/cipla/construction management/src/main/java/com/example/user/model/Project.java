package com.example.user.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "project")
public class Project {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int pid;
	
	@Column(name = "pName")
	private String pName;
	
	@Column(name = "pManager")
	private String pManager;
	
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Project(int pid, String pName, String pManager) {
		super();
		this.pid = pid;
		this.pName = pName;
		this.pManager = pManager;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpManager() {
		return pManager;
	}
	public void setpManager(String pManager) {
		this.pManager = pManager;
	}
	@Override
	public String toString() {
		return "Project [pid=" + pid + ", pName=" + pName + ", pManager=" + pManager + "]";
	}
	
}
