package com.example.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.model.Property;
import com.example.user.service.PropertyService;

@RestController
@RequestMapping("/property")
public class PropertyController {
	
	@Autowired
	PropertyService service;
	
	@GetMapping("/getAllProperty")
	public List<Property> getAllProperty(){
		return service.getAllProperties();
	}
	
	@GetMapping("/getPropertyById/{id}")
	public ResponseEntity<String> getPropertyById(@PathVariable (value = "id") int id){
		try {
		Property property = service.getPropertyById(id);
		if (property.equals(null)) {
			return new ResponseEntity(HttpStatus.NOT_FOUND).ok("Property doesn't exists: "  +id);
		} else {
			return new ResponseEntity(HttpStatus.FOUND).ok(property.toString());
		}
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/saveProperty")
	public  ResponseEntity<String> saveProperty(@RequestBody Property Property) {
		try {
			return new ResponseEntity(HttpStatus.CREATED).ok("Property created successfully: "  + Property.toString());
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/updateProperty/{id}")
	public ResponseEntity<String> updateProperty(@RequestBody Property property) {

		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("Property created successfully: "  + service.updateProperty(property));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
		
		
	}
	
	@DeleteMapping("/deleteProperty/{id}")
	public ResponseEntity<String> deleteProperty(@PathVariable (value = "id") int id) {
		try{
			return new ResponseEntity(HttpStatus.CREATED).ok("Property created successfully: "  + service.deleteProperty(id));
		}catch(Error error) {
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
	}
}
