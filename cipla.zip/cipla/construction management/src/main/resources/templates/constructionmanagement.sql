create database constructionmanagementsystem;
use constructionmanagementsystem;

create table user (
id int(3) NOT NULL AUTO_INCREMENT,
name varchar(120) NOT NULL,
email varchar(120) NOT NULL,
phone varchar (70) NOT NULL, 
password varchar(150),
PRIMARY KEY(id)
);

INSERT INTO USER VALUE (1,"ASHIS","ASHIS.NAHAK@PRODEVANS.COM",6371389321,"WELCOME@123");

create table property (
propertyId int(3) NOT NULL AUTO_INCREMENT,
propertyName varchar(120) NOT NULL,
propertyLocation varchar(120) NOT NULL,
PRIMARY KEY(propertyId)
);

INSERT INTO property VALUE (1,"ASHIS","berhampur");


create table project (
pid int(3) NOT NULL AUTO_INCREMENT,
pname varchar(120) NOT NULL,
pmanager varchar(120) NOT NULL,
PRIMARY KEY(pid)
);

drop table project;
INSERT INTO project VALUE (1,"ASHIS","subha");
select * from project;


create table role (
rId int(3) NOT NULL AUTO_INCREMENT,
rName varchar(120) NOT NULL,
PRIMARY KEY(rId)
);

INSERT INTO role VALUE (1,"admin");
select * from role;


